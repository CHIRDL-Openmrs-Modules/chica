/*
   This script sets up the printer configuration attributes for three printer_locations: PEREG1, PEREG2, PEREG3
   for one form: PSF
*/


/*
   Adds printer configuration atd_form_attributes for the PEREG1 printer location 
*/
INSERT INTO atd_form_attribute(name,description)
VALUES ('defaultPrinter PEREG1', 'default printer location');

INSERT INTO atd_form_attribute(name,description) 
VALUES ('alternatePrinter PEREG1', 'alternate printer location');

INSERT INTO atd_form_attribute(name,description) 
VALUES ('useAlternatePrinter PEREG1', 'boolean stating whether alternate printer location should be used');

/*
   Adds printer configuration atd_form_attributes for the PEREG2 printer location 
*/
INSERT INTO atd_form_attribute(name,description) 
VALUES ('defaultPrinter PEREG2', 'default printer location');

INSERT INTO atd_form_attribute(name,description) 
VALUES ('alternatePrinter PEREG2', 'alternate printer location');

INSERT INTO atd_form_attribute(name,description) 
VALUES ('useAlternatePrinter PEREG2', 'boolean stating whether alternate printer location should be used');

/*
   Adds printer configuration atd_form_attributes for the PEREG3 printer location 
*/
INSERT INTO atd_form_attribute(name,description) 
VALUES ('defaultPrinter PEREG3', 'default printer location');

INSERT INTO atd_form_attribute(name,description) 
VALUES ('alternatePrinter PEREG3', 'alternate printer location');

INSERT INTO atd_form_attribute(name,description) 
VALUES ('useAlternatePrinter PEREG3', 'boolean stating whether alternate printer location should be used');


/*
   Sets the value of the printer location attributes for form PSF and printer_location PEREG1
*/
INSERT INTO atd_form_attribute_value(form_id,value,form_attribute_id)
select max(form_id),'<default printer address>',max(form_attribute_id) from form a, atd_form_attribute b
where a.name='PSF' and b.name='defaultPrinter PEREG1';

INSERT INTO atd_form_attribute_value(form_id,value,form_attribute_id)
select max(form_id),'<alternate printer address>',max(form_attribute_id) from form a, atd_form_attribute b
where a.name='PSF' and b.name='alternatePrinter PEREG1';

INSERT INTO atd_form_attribute_value(form_id,value,form_attribute_id)
select max(form_id),'false',max(form_attribute_id) from form a, atd_form_attribute b
where a.name='PSF' and b.name='useAlternatePrinter PEREG1';

/*
   Sets the value of the printer location attributes for form PSF and printer_location PEREG2
*/
INSERT INTO atd_form_attribute_value(form_id,value,form_attribute_id)
select max(form_id),'<default printer address>',max(form_attribute_id) from form a, atd_form_attribute b
where a.name='PSF' and b.name='defaultPrinter PEREG2';

INSERT INTO atd_form_attribute_value(form_id,value,form_attribute_id)
select max(form_id),'<alternate printer address>',max(form_attribute_id) from form a, atd_form_attribute b
where a.name='PSF' and b.name='alternatePrinter PEREG2';

INSERT INTO atd_form_attribute_value(form_id,value,form_attribute_id)
select max(form_id),'false',max(form_attribute_id) from form a, atd_form_attribute b
where a.name='PSF' and b.name='useAlternatePrinter PEREG2';

/*
   Sets the value of the printer location attributes for form PSF and printer_location PEREG3
*/
INSERT INTO atd_form_attribute_value(form_id,value,form_attribute_id)
select max(form_id),'<default printer address>',max(form_attribute_id) from form a, atd_form_attribute b
where a.name='PSF' and b.name='defaultPrinter PEREG3';

INSERT INTO atd_form_attribute_value(form_id,value,form_attribute_id)
select max(form_id),'<default printer address>',max(form_attribute_id) from form a, atd_form_attribute b
where a.name='PSF' and b.name='alternatePrinter PEREG3';

INSERT INTO atd_form_attribute_value(form_id,value,form_attribute_id)
select max(form_id),'false',max(form_attribute_id) from form a, atd_form_attribute b
where a.name='PSF' and b.name='useAlternatePrinter PEREG3';