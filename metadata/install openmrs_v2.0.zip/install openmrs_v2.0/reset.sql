drop database if exists openmrs;
